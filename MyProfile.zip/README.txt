A web application for my profile (CV) created for technical exam.

Built on PHP/HTML5/CSS3/some JavaScript and used XAMPP MySQL (localhost only)

Exported database file - myprofile.sql

Index page - http://localhost/MyProfile/index.php

Three main pages -
   Index/Login - index.php
   Home/About - home.php
   Career Objectives - career.php

Admin account-
   message me for this